/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: interp1.c
 *
 * MATLAB Coder version            : 3.3
 * C/C++ source code generated on  : 15-Dec-2017 23:19:57
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "FIR_filtering.h"
#include "Linear_upconvert.h"
#include "Pchip_upconvert.h"
#include "Spline_upconvert.h"
#include "interp1.h"
#include "bsearch.h"
#include "CUpsampler_emxutil.h"
#include "pchip.h"

/* Function Definitions */

/*
 * Arguments    : const emxArray_real_T *varargin_1
 *                const emxArray_real_T *varargin_2
 *                emxArray_real_T *Vq
 * Return Type  : void
 */
void interp1(const emxArray_real_T *varargin_1, const emxArray_real_T
             *varargin_2, emxArray_real_T *Vq)
{
  int nycols;
  unsigned int outsize[2];
  int j;
  int nx;
  emxArray_real_T *x;
  int c1;
  emxArray_real_T *yp;
  int nxi;
  emxArray_real_T *h;
  int c0;
  int k;
  int m;
  emxArray_real_T *del;
  int szdel[2];
  int c2;
  emxArray_real_T *slopes;
  double hs;
  emxArray_real_T *pp_breaks;
  double hs3;
  emxArray_real_T *pp_coefs;
  double w1;
  int szc[3];
  emxArray_real_T *yit;
  int coefStride;
  unsigned int szv_idx_0;
  nycols = varargin_1->size[1];
  outsize[0] = (unsigned int)varargin_2->size[1];
  outsize[1] = (unsigned int)varargin_1->size[1];
  j = Vq->size[0] * Vq->size[1];
  Vq->size[0] = (int)outsize[0];
  Vq->size[1] = (int)outsize[1];
  emxEnsureCapacity((emxArray__common *)Vq, j, sizeof(double));
  nx = (int)outsize[0] * (int)outsize[1];
  for (j = 0; j < nx; j++) {
    Vq->data[j] = 0.0;
  }

  if (varargin_2->size[1] != 0) {
    emxInit_real_T(&x, 2);
    if (varargin_1->size[0] < 1) {
      j = x->size[0] * x->size[1];
      x->size[0] = 1;
      x->size[1] = 0;
      emxEnsureCapacity((emxArray__common *)x, j, sizeof(double));
    } else {
      j = varargin_1->size[0];
      c1 = x->size[0] * x->size[1];
      x->size[0] = 1;
      x->size[1] = (int)((double)j - 1.0) + 1;
      emxEnsureCapacity((emxArray__common *)x, c1, sizeof(double));
      nx = (int)((double)j - 1.0);
      for (j = 0; j <= nx; j++) {
        x->data[x->size[0] * j] = 1.0 + (double)j;
      }
    }

    emxInit_real_T(&yp, 2);
    nxi = varargin_2->size[1];
    j = yp->size[0] * yp->size[1];
    yp->size[0] = varargin_1->size[1];
    yp->size[1] = varargin_1->size[0];
    emxEnsureCapacity((emxArray__common *)yp, j, sizeof(double));
    nx = varargin_1->size[0];
    for (j = 0; j < nx; j++) {
      c0 = varargin_1->size[1];
      for (c1 = 0; c1 < c0; c1++) {
        yp->data[c1 + yp->size[0] * j] = varargin_1->data[j + varargin_1->size[0]
          * c1];
      }
    }

    emxInit_real_T(&h, 2);
    nx = x->size[1] - 1;
    j = h->size[0] * h->size[1];
    h->size[0] = 1;
    h->size[1] = x->size[1] - 1;
    emxEnsureCapacity((emxArray__common *)h, j, sizeof(double));
    for (k = 1; k <= nx; k++) {
      h->data[k - 1] = x->data[k] - x->data[k - 1];
    }

    m = yp->size[0];
    for (j = 0; j < 2; j++) {
      szdel[j] = yp->size[j];
    }

    emxInit_real_T(&del, 2);
    szdel[1]--;
    j = del->size[0] * del->size[1];
    del->size[0] = szdel[0];
    del->size[1] = szdel[1];
    emxEnsureCapacity((emxArray__common *)del, j, sizeof(double));
    for (k = 1; k <= nx; k++) {
      c1 = (k - 1) * m;
      c2 = k * m;
      for (j = 0; j + 1 <= m; j++) {
        hs = yp->data[c2 + j] - yp->data[c1 + j];
        del->data[c1 + j] = hs / h->data[k - 1];
      }
    }

    for (j = 0; j < 2; j++) {
      outsize[j] = (unsigned int)yp->size[j];
    }

    emxInit_real_T(&slopes, 2);
    j = slopes->size[0] * slopes->size[1];
    slopes->size[0] = (int)outsize[0];
    slopes->size[1] = (int)outsize[1];
    emxEnsureCapacity((emxArray__common *)slopes, j, sizeof(double));
    if (x->size[1] == 2) {
      for (k = 0; k < 2; k++) {
        c1 = k * m;
        for (j = 0; j + 1 <= m; j++) {
          slopes->data[c1 + j] = del->data[j];
        }
      }
    } else {
      for (k = 1; k < nx; k++) {
        hs = h->data[k - 1] + h->data[k];
        hs3 = 3.0 * hs;
        w1 = (h->data[k - 1] + hs) / hs3;
        hs = (h->data[k] + hs) / hs3;
        c1 = (k - 1) * m;
        c2 = k * m;
        for (j = 0; j + 1 <= m; j++) {
          hs3 = 0.0;
          if (del->data[c1 + j] < 0.0) {
            if (del->data[c2 + j] <= del->data[c1 + j]) {
              hs3 = del->data[c1 + j] / (w1 * (del->data[c1 + j] / del->data[c2
                + j]) + hs);
            } else {
              if (del->data[c2 + j] < 0.0) {
                hs3 = del->data[c2 + j] / (w1 + hs * (del->data[c2 + j] /
                  del->data[c1 + j]));
              }
            }
          } else {
            if (del->data[c1 + j] > 0.0) {
              if (del->data[c2 + j] >= del->data[c1 + j]) {
                hs3 = del->data[c1 + j] / (w1 * (del->data[c1 + j] / del->
                  data[c2 + j]) + hs);
              } else {
                if (del->data[c2 + j] > 0.0) {
                  hs3 = del->data[c2 + j] / (w1 + hs * (del->data[c2 + j] /
                    del->data[c1 + j]));
                }
              }
            }
          }

          slopes->data[c2 + j] = hs3;
        }
      }

      c0 = (x->size[1] - 1) * yp->size[0];
      c1 = (x->size[1] - 2) * yp->size[0];
      c2 = (x->size[1] - 3) * yp->size[0];
      for (j = 0; j + 1 <= m; j++) {
        slopes->data[j] = exteriorSlope(del->data[j], del->data[j + m], h->data
          [0], h->data[1]);
        slopes->data[j + c0] = exteriorSlope(del->data[j + c1], del->data[j + c2],
          h->data[nx - 1], h->data[nx - 2]);
      }
    }

    emxInit_real_T(&pp_breaks, 2);
    emxInit_real_T2(&pp_coefs, 3);
    nx = x->size[1];
    j = pp_breaks->size[0] * pp_breaks->size[1];
    pp_breaks->size[0] = 1;
    pp_breaks->size[1] = nx;
    emxEnsureCapacity((emxArray__common *)pp_breaks, j, sizeof(double));
    for (j = 0; j < nx; j++) {
      pp_breaks->data[pp_breaks->size[0] * j] = x->data[j];
    }

    c0 = slopes->size[0];
    c2 = slopes->size[0] * (x->size[1] - 1);
    for (j = 0; j < 2; j++) {
      szc[j] = slopes->size[j];
    }

    szc[1] = x->size[1] - 1;
    j = pp_coefs->size[0] * pp_coefs->size[1] * pp_coefs->size[2];
    pp_coefs->size[0] = szc[0];
    pp_coefs->size[1] = szc[1];
    pp_coefs->size[2] = 4;
    emxEnsureCapacity((emxArray__common *)pp_coefs, j, sizeof(double));
    for (j = 0; j + 1 < x->size[1]; j++) {
      hs3 = h->data[j];
      nx = j * c0;
      for (c1 = 0; c1 + 1 <= c0; c1++) {
        hs = del->data[nx + c1] - slopes->data[nx + c1];
        w1 = hs / hs3;
        hs = slopes->data[(nx + c0) + c1] - del->data[nx + c1];
        hs /= hs3;
        pp_coefs->data[nx + c1] = (hs - w1) / hs3;
        pp_coefs->data[(c2 + nx) + c1] = 2.0 * w1 - hs;
        pp_coefs->data[((c2 << 1) + nx) + c1] = slopes->data[nx + c1];
        pp_coefs->data[(3 * c2 + nx) + c1] = yp->data[nx + c1];
      }
    }

    emxFree_real_T(&slopes);
    emxFree_real_T(&del);
    emxFree_real_T(&h);
    emxFree_real_T(&x);
    emxFree_real_T(&yp);
    k = 0;
    emxInit_real_T1(&yit, 1);
    while (k + 1 <= nxi) {
      if (rtIsNaN(varargin_2->data[k])) {
        for (j = 1; j <= nycols; j++) {
          Vq->data[(j - 1) * nxi + k] = rtNaN;
        }
      } else {
        m = pp_coefs->size[0];
        coefStride = pp_coefs->size[0] * (pp_breaks->size[1] - 1);
        szv_idx_0 = (unsigned int)pp_coefs->size[0];
        j = yit->size[0];
        yit->size[0] = (int)szv_idx_0;
        emxEnsureCapacity((emxArray__common *)yit, j, sizeof(double));
        if (pp_coefs->size[0] == 1) {
          if (rtIsNaN(varargin_2->data[k])) {
            hs3 = varargin_2->data[k];
          } else {
            nx = b_bsearch(pp_breaks, varargin_2->data[k]) - 1;
            hs = varargin_2->data[k] - pp_breaks->data[nx];
            hs3 = pp_coefs->data[nx];
            for (c2 = 0; c2 < 3; c2++) {
              hs3 = hs * hs3 + pp_coefs->data[nx + (c2 + 1) * coefStride];
            }
          }

          yit->data[0] = hs3;
        } else if (rtIsNaN(varargin_2->data[k])) {
          for (j = 1; j <= m; j++) {
            yit->data[j - 1] = varargin_2->data[k];
          }
        } else {
          nx = b_bsearch(pp_breaks, varargin_2->data[k]) - 1;
          c1 = nx * pp_coefs->size[0];
          hs = varargin_2->data[k] - pp_breaks->data[nx];
          for (j = 0; j + 1 <= m; j++) {
            yit->data[j] = pp_coefs->data[c1 + j];
          }

          for (c2 = 0; c2 < 3; c2++) {
            c0 = c1 + (c2 + 1) * coefStride;
            for (j = 0; j + 1 <= m; j++) {
              yit->data[j] = hs * yit->data[j] + pp_coefs->data[c0 + j];
            }
          }
        }

        for (j = 0; j + 1 <= nycols; j++) {
          Vq->data[j * nxi + k] = yit->data[j];
        }
      }

      k++;
    }

    emxFree_real_T(&pp_coefs);
    emxFree_real_T(&pp_breaks);
    emxFree_real_T(&yit);
  }
}

/*
 * File trailer for interp1.c
 *
 * [EOF]
 */
