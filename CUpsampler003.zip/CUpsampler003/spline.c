/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: spline.c
 *
 * MATLAB Coder version            : 3.3
 * C/C++ source code generated on  : 15-Dec-2017 23:19:57
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "FIR_filtering.h"
#include "Linear_upconvert.h"
#include "Pchip_upconvert.h"
#include "Spline_upconvert.h"
#include "spline.h"
#include "CUpsampler_emxutil.h"
#include "pwchcore.h"

/* Function Definitions */

/*
 * Arguments    : const emxArray_real_T *x
 *                const emxArray_real_T *y
 *                emxArray_real_T *output_breaks
 *                emxArray_real_T *output_coefs
 * Return Type  : void
 */
void spline(const emxArray_real_T *x, const emxArray_real_T *y, emxArray_real_T *
            output_breaks, emxArray_real_T *output_coefs)
{
  int nx;
  int pglen;
  boolean_T has_endslopes;
  emxArray_real_T *t1_breaks;
  emxArray_real_T *t1_coefs;
  emxArray_real_T *c;
  emxArray_real_T *dx;
  emxArray_real_T *dvdf;
  int pgm1;
  emxArray_real_T *s;
  emxArray_real_T *md;
  unsigned int b_y[3];
  int pgm2;
  int j;
  int szdvdf[2];
  double d1;
  int yoffset;
  int szs[2];
  double d31;
  double A;
  double dnnm2;
  double b_x[2];
  double dvdf1;
  int k;
  int pg;
  nx = x->size[1] - 1;
  pglen = y->size[0];
  has_endslopes = (y->size[1] == x->size[1] + 2);
  emxInit_real_T(&t1_breaks, 2);
  emxInit_real_T2(&t1_coefs, 3);
  if (x->size[1] <= 2) {
    if (has_endslopes) {
      emxInit_real_T(&dx, 2);
      pgm1 = dx->size[0] * dx->size[1];
      dx->size[0] = y->size[0];
      dx->size[1] = 2;
      emxEnsureCapacity((emxArray__common *)dx, pgm1, sizeof(double));
      pgm2 = (y->size[1] - 1) * y->size[0];
      for (j = 0; j + 1 <= pglen; j++) {
        dx->data[j] = y->data[j];
        dx->data[pglen + j] = y->data[pgm2 + j];
      }

      pwchcore(x, y, y->size[0], dx, t1_breaks, t1_coefs);
      pgm1 = output_breaks->size[0] * output_breaks->size[1];
      output_breaks->size[0] = 1;
      output_breaks->size[1] = t1_breaks->size[1];
      emxEnsureCapacity((emxArray__common *)output_breaks, pgm1, sizeof(double));
      pgm2 = t1_breaks->size[0] * t1_breaks->size[1];
      emxFree_real_T(&dx);
      for (pgm1 = 0; pgm1 < pgm2; pgm1++) {
        output_breaks->data[pgm1] = t1_breaks->data[pgm1];
      }

      pgm1 = output_coefs->size[0] * output_coefs->size[1] * output_coefs->size
        [2];
      output_coefs->size[0] = t1_coefs->size[0];
      output_coefs->size[1] = t1_coefs->size[1];
      output_coefs->size[2] = 4;
      emxEnsureCapacity((emxArray__common *)output_coefs, pgm1, sizeof(double));
      pgm2 = t1_coefs->size[0] * t1_coefs->size[1] * t1_coefs->size[2];
      for (pgm1 = 0; pgm1 < pgm2; pgm1++) {
        output_coefs->data[pgm1] = t1_coefs->data[pgm1];
      }
    } else {
      emxInit_real_T2(&c, 3);
      for (pgm1 = 0; pgm1 < 2; pgm1++) {
        b_y[pgm1] = (unsigned int)y->size[pgm1];
      }

      pgm1 = c->size[0] * c->size[1] * c->size[2];
      c->size[0] = (int)b_y[0];
      c->size[1] = 1;
      c->size[2] = 2;
      emxEnsureCapacity((emxArray__common *)c, pgm1, sizeof(double));
      d1 = x->data[1] - x->data[0];
      for (j = 0; j + 1 <= pglen; j++) {
        A = y->data[pglen + j] - y->data[j];
        c->data[j] = A / d1;
        c->data[pglen + j] = y->data[j];
      }

      emxInit_real_T(&dx, 2);
      pgm2 = x->size[1];
      pgm1 = dx->size[0] * dx->size[1];
      dx->size[0] = 1;
      dx->size[1] = pgm2;
      emxEnsureCapacity((emxArray__common *)dx, pgm1, sizeof(double));
      for (pgm1 = 0; pgm1 < pgm2; pgm1++) {
        dx->data[dx->size[0] * pgm1] = x->data[pgm1];
      }

      pgm1 = output_breaks->size[0] * output_breaks->size[1];
      output_breaks->size[0] = 1;
      output_breaks->size[1] = dx->size[1];
      emxEnsureCapacity((emxArray__common *)output_breaks, pgm1, sizeof(double));
      pgm2 = dx->size[0] * dx->size[1];
      for (pgm1 = 0; pgm1 < pgm2; pgm1++) {
        output_breaks->data[pgm1] = dx->data[pgm1];
      }

      emxFree_real_T(&dx);
      pgm1 = output_coefs->size[0] * output_coefs->size[1] * output_coefs->size
        [2];
      output_coefs->size[0] = c->size[0];
      output_coefs->size[1] = 1;
      output_coefs->size[2] = 2;
      emxEnsureCapacity((emxArray__common *)output_coefs, pgm1, sizeof(double));
      pgm2 = c->size[0] * c->size[1] * c->size[2];
      for (pgm1 = 0; pgm1 < pgm2; pgm1++) {
        output_coefs->data[pgm1] = c->data[pgm1];
      }

      emxFree_real_T(&c);
    }
  } else {
    emxInit_real_T2(&c, 3);
    emxInit_real_T(&dx, 2);
    emxInit_real_T(&dvdf, 2);
    emxInit_real_T(&s, 2);
    emxInit_real_T(&md, 2);
    if ((x->size[1] == 3) && (!has_endslopes)) {
      for (pgm1 = 0; pgm1 < 2; pgm1++) {
        b_y[pgm1] = (unsigned int)y->size[pgm1];
      }

      pgm1 = c->size[0] * c->size[1] * c->size[2];
      c->size[0] = (int)b_y[0];
      c->size[1] = 1;
      c->size[2] = 3;
      emxEnsureCapacity((emxArray__common *)c, pgm1, sizeof(double));
      d31 = x->data[2] - x->data[0];
      d1 = x->data[1] - x->data[0];
      dnnm2 = x->data[2] - x->data[1];
      for (j = 0; j + 1 <= pglen; j++) {
        A = y->data[pglen + j] - y->data[j];
        dvdf1 = A / d1;
        A = y->data[(pglen << 1) + j] - y->data[pglen + j];
        c->data[j] = (A / dnnm2 - dvdf1) / d31;
        c->data[pglen + j] = dvdf1 - c->data[j] * d1;
        c->data[(pglen << 1) + j] = y->data[j];
      }

      b_x[0] = x->data[0];
      b_x[1] = x->data[2];
      pgm1 = output_breaks->size[0] * output_breaks->size[1];
      output_breaks->size[0] = 1;
      output_breaks->size[1] = 2;
      emxEnsureCapacity((emxArray__common *)output_breaks, pgm1, sizeof(double));
      for (pgm1 = 0; pgm1 < 2; pgm1++) {
        output_breaks->data[output_breaks->size[0] * pgm1] = b_x[pgm1];
      }

      pgm1 = output_coefs->size[0] * output_coefs->size[1] * output_coefs->size
        [2];
      output_coefs->size[0] = c->size[0];
      output_coefs->size[1] = 1;
      output_coefs->size[2] = 3;
      emxEnsureCapacity((emxArray__common *)output_coefs, pgm1, sizeof(double));
      pgm2 = c->size[0] * c->size[1] * c->size[2];
      for (pgm1 = 0; pgm1 < pgm2; pgm1++) {
        output_coefs->data[pgm1] = c->data[pgm1];
      }
    } else {
      if (has_endslopes) {
        for (pgm1 = 0; pgm1 < 2; pgm1++) {
          szdvdf[pgm1] = y->size[pgm1];
        }

        szdvdf[1] = y->size[1] - 3;
        for (pgm1 = 0; pgm1 < 2; pgm1++) {
          szs[pgm1] = y->size[pgm1];
        }

        szs[1] = y->size[1] - 2;
        yoffset = y->size[0];
      } else {
        for (pgm1 = 0; pgm1 < 2; pgm1++) {
          szdvdf[pgm1] = y->size[pgm1];
        }

        szdvdf[1] = y->size[1] - 1;
        for (pgm1 = 0; pgm1 < 2; pgm1++) {
          szs[pgm1] = y->size[pgm1];
        }

        yoffset = 0;
      }

      pgm1 = x->size[1] - 1;
      pgm2 = dx->size[0] * dx->size[1];
      dx->size[0] = 1;
      dx->size[1] = pgm1;
      emxEnsureCapacity((emxArray__common *)dx, pgm2, sizeof(double));
      pgm1 = dvdf->size[0] * dvdf->size[1];
      dvdf->size[0] = szdvdf[0];
      dvdf->size[1] = szdvdf[1];
      emxEnsureCapacity((emxArray__common *)dvdf, pgm1, sizeof(double));
      pgm1 = s->size[0] * s->size[1];
      s->size[0] = szs[0];
      s->size[1] = szs[1];
      emxEnsureCapacity((emxArray__common *)s, pgm1, sizeof(double));
      for (k = 0; k + 1 <= nx; k++) {
        dx->data[k] = x->data[k + 1] - x->data[k];
        pgm1 = k * pglen;
        pg = yoffset + pgm1;
        pgm2 = yoffset + (k + 1) * pglen;
        for (j = 0; j + 1 <= pglen; j++) {
          A = y->data[pgm2 + j] - y->data[pg + j];
          dvdf->data[pgm1 + j] = A / dx->data[k];
        }
      }

      for (k = 1; k + 1 <= nx; k++) {
        pg = k * pglen;
        pgm1 = (k - 1) * pglen;
        for (j = 0; j + 1 <= pglen; j++) {
          s->data[pg + j] = 3.0 * (dx->data[k] * dvdf->data[pgm1 + j] + dx->
            data[k - 1] * dvdf->data[pg + j]);
        }
      }

      if (has_endslopes) {
        d31 = 0.0;
        dnnm2 = 0.0;
        for (j = 0; j + 1 <= pglen; j++) {
          s->data[j] = dx->data[1] * y->data[j];
        }

        pgm2 = (x->size[1] + 1) * y->size[0];
        pgm1 = (x->size[1] - 1) * y->size[0];
        for (j = 0; j + 1 <= pglen; j++) {
          s->data[pgm1 + j] = dx->data[nx - 2] * y->data[pgm2 + j];
        }
      } else {
        d31 = x->data[2] - x->data[0];
        dnnm2 = x->data[x->size[1] - 1] - x->data[x->size[1] - 3];
        d1 = dx->data[0];
        for (j = 0; j + 1 <= pglen; j++) {
          A = (d1 + 2.0 * d31) * dx->data[1] * dvdf->data[j] + d1 * d1 *
            dvdf->data[pglen + j];
          s->data[j] = A / d31;
        }

        pg = (x->size[1] - 1) * y->size[0];
        pgm1 = (x->size[1] - 2) * y->size[0];
        pgm2 = (x->size[1] - 3) * y->size[0];
        d1 = dx->data[x->size[1] - 2];
        for (j = 0; j + 1 <= pglen; j++) {
          A = (d1 + 2.0 * dnnm2) * dx->data[x->size[1] - 3] * dvdf->data[pgm1 +
            j] + d1 * d1 * dvdf->data[pgm2 + j];
          s->data[pg + j] = A / dnnm2;
        }
      }

      pgm1 = md->size[0] * md->size[1];
      md->size[0] = x->size[0];
      md->size[1] = x->size[1];
      emxEnsureCapacity((emxArray__common *)md, pgm1, sizeof(double));
      md->data[0] = dx->data[1];
      md->data[x->size[1] - 1] = dx->data[x->size[1] - 3];
      for (k = 1; k + 1 <= nx; k++) {
        md->data[k] = 2.0 * (dx->data[k] + dx->data[k - 1]);
      }

      d1 = dx->data[1] / md->data[0];
      md->data[1] -= d1 * d31;
      for (j = 0; j + 1 <= pglen; j++) {
        s->data[pglen + j] -= d1 * s->data[j];
      }

      for (k = 2; k + 1 <= nx; k++) {
        d1 = dx->data[k] / md->data[k - 1];
        md->data[k] -= d1 * dx->data[k - 2];
        pg = k * pglen;
        pgm1 = (k - 1) * pglen;
        for (j = 0; j + 1 <= pglen; j++) {
          s->data[pg + j] -= d1 * s->data[pgm1 + j];
        }
      }

      d1 = dnnm2 / md->data[x->size[1] - 2];
      md->data[x->size[1] - 1] -= d1 * dx->data[x->size[1] - 3];
      pg = (x->size[1] - 1) * y->size[0];
      pgm1 = (x->size[1] - 2) * y->size[0];
      for (j = 0; j + 1 <= pglen; j++) {
        s->data[pg + j] -= d1 * s->data[pgm1 + j];
      }

      for (j = 0; j + 1 <= pglen; j++) {
        A = s->data[pg + j];
        s->data[pg + j] = A / md->data[nx];
      }

      for (k = x->size[1] - 1; k > 1; k--) {
        pg = (k - 1) * pglen;
        pgm2 = k * pglen;
        for (j = 0; j + 1 <= pglen; j++) {
          A = s->data[pg + j] - dx->data[k - 2] * s->data[pgm2 + j];
          s->data[pg + j] = A / md->data[k - 1];
        }
      }

      for (j = 0; j + 1 <= pglen; j++) {
        A = s->data[j] - d31 * s->data[pglen + j];
        s->data[j] = A / md->data[0];
      }

      b_pwchcore(x, y, yoffset, s, dx, dvdf, t1_breaks, t1_coefs);
      pgm1 = output_breaks->size[0] * output_breaks->size[1];
      output_breaks->size[0] = 1;
      output_breaks->size[1] = t1_breaks->size[1];
      emxEnsureCapacity((emxArray__common *)output_breaks, pgm1, sizeof(double));
      pgm2 = t1_breaks->size[0] * t1_breaks->size[1];
      for (pgm1 = 0; pgm1 < pgm2; pgm1++) {
        output_breaks->data[pgm1] = t1_breaks->data[pgm1];
      }

      pgm1 = output_coefs->size[0] * output_coefs->size[1] * output_coefs->size
        [2];
      output_coefs->size[0] = t1_coefs->size[0];
      output_coefs->size[1] = t1_coefs->size[1];
      output_coefs->size[2] = 4;
      emxEnsureCapacity((emxArray__common *)output_coefs, pgm1, sizeof(double));
      pgm2 = t1_coefs->size[0] * t1_coefs->size[1] * t1_coefs->size[2];
      for (pgm1 = 0; pgm1 < pgm2; pgm1++) {
        output_coefs->data[pgm1] = t1_coefs->data[pgm1];
      }
    }

    emxFree_real_T(&md);
    emxFree_real_T(&s);
    emxFree_real_T(&dvdf);
    emxFree_real_T(&dx);
    emxFree_real_T(&c);
  }

  emxFree_real_T(&t1_coefs);
  emxFree_real_T(&t1_breaks);
}

/*
 * File trailer for spline.c
 *
 * [EOF]
 */
