/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: Spline_upconvert.h
 *
 * MATLAB Coder version            : 3.3
 * C/C++ source code generated on  : 15-Dec-2017 23:19:57
 */

#ifndef SPLINE_UPCONVERT_H
#define SPLINE_UPCONVERT_H

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "CUpsampler_types.h"

/* Function Declarations */
extern void Spline_upconvert(const emxArray_real_T *music, double fs, double x,
  emxArray_real_T *music_x, double *fs_x);

#endif

/*
 * File trailer for Spline_upconvert.h
 *
 * [EOF]
 */
