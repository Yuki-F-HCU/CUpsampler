/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: Spline_upconvert.c
 *
 * MATLAB Coder version            : 3.3
 * C/C++ source code generated on  : 15-Dec-2017 23:19:57
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "FIR_filtering.h"
#include "Linear_upconvert.h"
#include "Pchip_upconvert.h"
#include "Spline_upconvert.h"
#include "bsearch.h"
#include "CUpsampler_emxutil.h"
#include "spline.h"

/* Function Definitions */

/*
 * Arguments    : const emxArray_real_T *music
 *                double fs
 *                double x
 *                emxArray_real_T *music_x
 *                double *fs_x
 * Return Type  : void
 */
void Spline_upconvert(const emxArray_real_T *music, double fs, double x,
                      emxArray_real_T *music_x, double *fs_x)
{
  emxArray_real_T *y;
  double b_y;
  int ic;
  double ndbl;
  double apnd;
  int absb;
  double cdiff;
  int nycols;
  unsigned int outsize_idx_0;
  int ic0;
  unsigned int outsize_idx_1;
  emxArray_real_T *b_x;
  emxArray_real_T *b_music;
  int nxi;
  int k;
  emxArray_real_T *pp_breaks;
  int icp;
  emxArray_real_T *pp_coefs;
  emxArray_real_T *yit;
  int numTerms;
  int elementsPerPage;
  int coefStride;
  emxInit_real_T(&y, 2);
  b_y = 1.0 / x;
  if (rtIsNaN(b_y)) {
    ic = y->size[0] * y->size[1];
    y->size[0] = 1;
    y->size[1] = 1;
    emxEnsureCapacity((emxArray__common *)y, ic, sizeof(double));
    y->data[0] = rtNaN;
  } else if ((b_y == 0.0) || ((1 < music->size[0]) && (b_y < 0.0)) ||
             ((music->size[0] < 1) && (b_y > 0.0))) {
    ic = y->size[0] * y->size[1];
    y->size[0] = 1;
    y->size[1] = 0;
    emxEnsureCapacity((emxArray__common *)y, ic, sizeof(double));
  } else if (rtIsInf(b_y)) {
    ic = y->size[0] * y->size[1];
    y->size[0] = 1;
    y->size[1] = 1;
    emxEnsureCapacity((emxArray__common *)y, ic, sizeof(double));
    y->data[0] = 1.0;
  } else if (floor(b_y) == b_y) {
    ic = music->size[0];
    absb = y->size[0] * y->size[1];
    y->size[0] = 1;
    y->size[1] = (int)floor(((double)ic - 1.0) / b_y) + 1;
    emxEnsureCapacity((emxArray__common *)y, absb, sizeof(double));
    ic0 = (int)floor(((double)ic - 1.0) / b_y);
    for (ic = 0; ic <= ic0; ic++) {
      y->data[y->size[0] * ic] = 1.0 + b_y * (double)ic;
    }
  } else {
    ndbl = floor(((double)music->size[0] - 1.0) / b_y + 0.5);
    apnd = 1.0 + ndbl * b_y;
    if (b_y > 0.0) {
      cdiff = apnd - (double)music->size[0];
    } else {
      cdiff = (double)music->size[0] - apnd;
    }

    absb = music->size[0];
    if (1 > absb) {
      absb = 1;
    }

    if (fabs(cdiff) < 4.4408920985006262E-16 * (double)absb) {
      ndbl++;
      apnd = music->size[0];
    } else if (cdiff > 0.0) {
      apnd = 1.0 + (ndbl - 1.0) * b_y;
    } else {
      ndbl++;
    }

    if (ndbl >= 0.0) {
      ic0 = (int)ndbl;
    } else {
      ic0 = 0;
    }

    ic = y->size[0] * y->size[1];
    y->size[0] = 1;
    y->size[1] = ic0;
    emxEnsureCapacity((emxArray__common *)y, ic, sizeof(double));
    if (ic0 > 0) {
      y->data[0] = 1.0;
      if (ic0 > 1) {
        y->data[ic0 - 1] = apnd;
        absb = (ic0 - 1) / 2;
        for (k = 1; k < absb; k++) {
          cdiff = (double)k * b_y;
          y->data[k] = 1.0 + cdiff;
          y->data[(ic0 - k) - 1] = apnd - cdiff;
        }

        if (absb << 1 == ic0 - 1) {
          y->data[absb] = (1.0 + apnd) / 2.0;
        } else {
          cdiff = (double)absb * b_y;
          y->data[absb] = 1.0 + cdiff;
          y->data[absb + 1] = apnd - cdiff;
        }
      }
    }
  }

  nycols = music->size[1];
  outsize_idx_0 = (unsigned int)y->size[1];
  outsize_idx_1 = (unsigned int)music->size[1];
  ic = music_x->size[0] * music_x->size[1];
  music_x->size[0] = (int)outsize_idx_0;
  music_x->size[1] = (int)outsize_idx_1;
  emxEnsureCapacity((emxArray__common *)music_x, ic, sizeof(double));
  ic0 = (int)outsize_idx_0 * (int)outsize_idx_1;
  for (ic = 0; ic < ic0; ic++) {
    music_x->data[ic] = 0.0;
  }

  if (y->size[1] != 0) {
    emxInit_real_T(&b_x, 2);
    if (music->size[0] < 1) {
      ic = b_x->size[0] * b_x->size[1];
      b_x->size[0] = 1;
      b_x->size[1] = 0;
      emxEnsureCapacity((emxArray__common *)b_x, ic, sizeof(double));
    } else {
      ic = music->size[0];
      absb = b_x->size[0] * b_x->size[1];
      b_x->size[0] = 1;
      b_x->size[1] = (int)((double)ic - 1.0) + 1;
      emxEnsureCapacity((emxArray__common *)b_x, absb, sizeof(double));
      ic0 = (int)((double)ic - 1.0);
      for (ic = 0; ic <= ic0; ic++) {
        b_x->data[b_x->size[0] * ic] = 1.0 + (double)ic;
      }
    }

    emxInit_real_T(&b_music, 2);
    nxi = y->size[1];
    ic = b_music->size[0] * b_music->size[1];
    b_music->size[0] = music->size[1];
    b_music->size[1] = music->size[0];
    emxEnsureCapacity((emxArray__common *)b_music, ic, sizeof(double));
    ic0 = music->size[0];
    for (ic = 0; ic < ic0; ic++) {
      icp = music->size[1];
      for (absb = 0; absb < icp; absb++) {
        b_music->data[absb + b_music->size[0] * ic] = music->data[ic +
          music->size[0] * absb];
      }
    }

    emxInit_real_T(&pp_breaks, 2);
    emxInit_real_T2(&pp_coefs, 3);
    spline(b_x, b_music, pp_breaks, pp_coefs);
    k = 0;
    emxFree_real_T(&b_music);
    emxFree_real_T(&b_x);
    emxInit_real_T1(&yit, 1);
    while (k + 1 <= nxi) {
      if (rtIsNaN(y->data[k])) {
        for (absb = 1; absb <= nycols; absb++) {
          music_x->data[(absb - 1) * nxi + k] = rtNaN;
        }
      } else {
        numTerms = pp_coefs->size[2];
        elementsPerPage = pp_coefs->size[0];
        coefStride = pp_coefs->size[0] * (pp_breaks->size[1] - 1);
        outsize_idx_0 = (unsigned int)pp_coefs->size[0];
        ic = yit->size[0];
        yit->size[0] = (int)outsize_idx_0;
        emxEnsureCapacity((emxArray__common *)yit, ic, sizeof(double));
        if (pp_coefs->size[0] == 1) {
          if (rtIsNaN(y->data[k])) {
            ndbl = y->data[k];
          } else {
            absb = b_bsearch(pp_breaks, y->data[k]) - 1;
            cdiff = y->data[k] - pp_breaks->data[absb];
            ndbl = pp_coefs->data[absb];
            for (ic = 2; ic <= numTerms; ic++) {
              ndbl = cdiff * ndbl + pp_coefs->data[absb + (ic - 1) * coefStride];
            }
          }

          yit->data[0] = ndbl;
        } else if (rtIsNaN(y->data[k])) {
          for (absb = 1; absb <= elementsPerPage; absb++) {
            yit->data[absb - 1] = y->data[k];
          }
        } else {
          absb = b_bsearch(pp_breaks, y->data[k]) - 1;
          icp = absb * pp_coefs->size[0];
          cdiff = y->data[k] - pp_breaks->data[absb];
          for (absb = 0; absb + 1 <= elementsPerPage; absb++) {
            yit->data[absb] = pp_coefs->data[icp + absb];
          }

          for (ic = 2; ic <= numTerms; ic++) {
            ic0 = icp + (ic - 1) * coefStride;
            for (absb = 0; absb + 1 <= elementsPerPage; absb++) {
              yit->data[absb] = cdiff * yit->data[absb] + pp_coefs->data[ic0 +
                absb];
            }
          }
        }

        for (absb = 0; absb + 1 <= nycols; absb++) {
          music_x->data[absb * nxi + k] = yit->data[absb];
        }
      }

      k++;
    }

    emxFree_real_T(&yit);
    emxFree_real_T(&pp_coefs);
    emxFree_real_T(&pp_breaks);
  }

  emxFree_real_T(&y);

  /*  figure; */
  /*  plot(music); */
  /*  figure; */
  /*  plot(music_x); */
  *fs_x = fs * x;
}

/*
 * File trailer for Spline_upconvert.c
 *
 * [EOF]
 */
