/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: pwchcore.c
 *
 * MATLAB Coder version            : 3.3
 * C/C++ source code generated on  : 15-Dec-2017 23:19:57
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "FIR_filtering.h"
#include "Linear_upconvert.h"
#include "Pchip_upconvert.h"
#include "Spline_upconvert.h"
#include "pwchcore.h"
#include "CUpsampler_emxutil.h"

/* Function Definitions */

/*
 * Arguments    : const emxArray_real_T *x
 *                const emxArray_real_T *y
 *                int yoffset
 *                const emxArray_real_T *s
 *                const emxArray_real_T *dx
 *                const emxArray_real_T *divdif
 *                emxArray_real_T *pp_breaks
 *                emxArray_real_T *pp_coefs
 * Return Type  : void
 */
void b_pwchcore(const emxArray_real_T *x, const emxArray_real_T *y, int yoffset,
                const emxArray_real_T *s, const emxArray_real_T *dx, const
                emxArray_real_T *divdif, emxArray_real_T *pp_breaks,
                emxArray_real_T *pp_coefs)
{
  int x_idx_0;
  int joffset;
  int nyrows;
  int cpage;
  int szc[3];
  double dxj;
  int i;
  double dzdxdx;
  double dzzdx;
  x_idx_0 = x->size[1];
  joffset = pp_breaks->size[0] * pp_breaks->size[1];
  pp_breaks->size[0] = 1;
  pp_breaks->size[1] = x_idx_0;
  emxEnsureCapacity((emxArray__common *)pp_breaks, joffset, sizeof(double));
  for (joffset = 0; joffset < x_idx_0; joffset++) {
    pp_breaks->data[pp_breaks->size[0] * joffset] = x->data[joffset];
  }

  nyrows = s->size[0];
  cpage = s->size[0] * (x->size[1] - 1);
  for (joffset = 0; joffset < 2; joffset++) {
    szc[joffset] = s->size[joffset];
  }

  szc[1] = x->size[1] - 1;
  joffset = pp_coefs->size[0] * pp_coefs->size[1] * pp_coefs->size[2];
  pp_coefs->size[0] = szc[0];
  pp_coefs->size[1] = szc[1];
  pp_coefs->size[2] = 4;
  emxEnsureCapacity((emxArray__common *)pp_coefs, joffset, sizeof(double));
  for (x_idx_0 = 0; x_idx_0 + 1 < x->size[1]; x_idx_0++) {
    dxj = dx->data[x_idx_0];
    joffset = x_idx_0 * nyrows - 1;
    for (i = 1; i <= nyrows; i++) {
      dzdxdx = divdif->data[joffset + i] - s->data[joffset + i];
      dzzdx = dzdxdx / dxj;
      dzdxdx = s->data[(joffset + nyrows) + i] - divdif->data[joffset + i];
      dzdxdx /= dxj;
      pp_coefs->data[joffset + i] = (dzdxdx - dzzdx) / dxj;
      pp_coefs->data[(cpage + joffset) + i] = 2.0 * dzzdx - dzdxdx;
      pp_coefs->data[((cpage << 1) + joffset) + i] = s->data[joffset + i];
      pp_coefs->data[(3 * cpage + joffset) + i] = y->data[(yoffset + joffset) +
        i];
    }
  }
}

/*
 * Arguments    : const emxArray_real_T *x
 *                const emxArray_real_T *y
 *                int yoffset
 *                const emxArray_real_T *s
 *                emxArray_real_T *pp_breaks
 *                emxArray_real_T *pp_coefs
 * Return Type  : void
 */
void pwchcore(const emxArray_real_T *x, const emxArray_real_T *y, int yoffset,
              const emxArray_real_T *s, emxArray_real_T *pp_breaks,
              emxArray_real_T *pp_coefs)
{
  int x_idx_0;
  int joffset;
  int nyrows;
  int cpage;
  int szc[3];
  double dxj;
  int i;
  double dzdxdx;
  double divdifij;
  double dzzdx;
  x_idx_0 = x->size[1];
  joffset = pp_breaks->size[0] * pp_breaks->size[1];
  pp_breaks->size[0] = 1;
  pp_breaks->size[1] = x_idx_0;
  emxEnsureCapacity((emxArray__common *)pp_breaks, joffset, sizeof(double));
  for (joffset = 0; joffset < x_idx_0; joffset++) {
    pp_breaks->data[pp_breaks->size[0] * joffset] = x->data[joffset];
  }

  nyrows = s->size[0];
  cpage = s->size[0] * (x->size[1] - 1);
  for (joffset = 0; joffset < 2; joffset++) {
    szc[joffset] = s->size[joffset];
  }

  szc[1] = x->size[1] - 1;
  joffset = pp_coefs->size[0] * pp_coefs->size[1] * pp_coefs->size[2];
  pp_coefs->size[0] = szc[0];
  pp_coefs->size[1] = szc[1];
  pp_coefs->size[2] = 4;
  emxEnsureCapacity((emxArray__common *)pp_coefs, joffset, sizeof(double));
  for (x_idx_0 = 1; x_idx_0 < x->size[1]; x_idx_0++) {
    dxj = x->data[x_idx_0] - x->data[x_idx_0 - 1];
    joffset = (x_idx_0 - 1) * nyrows - 1;
    for (i = 1; i <= nyrows; i++) {
      dzdxdx = y->data[((yoffset + nyrows) + joffset) + i] - y->data[(yoffset +
        joffset) + i];
      divdifij = dzdxdx / dxj;
      dzdxdx = divdifij - s->data[joffset + i];
      dzzdx = dzdxdx / dxj;
      dzdxdx = s->data[(joffset + nyrows) + i] - divdifij;
      dzdxdx /= dxj;
      pp_coefs->data[joffset + i] = (dzdxdx - dzzdx) / dxj;
      pp_coefs->data[(cpage + joffset) + i] = 2.0 * dzzdx - dzdxdx;
      pp_coefs->data[((cpage << 1) + joffset) + i] = s->data[joffset + i];
      pp_coefs->data[(3 * cpage + joffset) + i] = y->data[(yoffset + joffset) +
        i];
    }
  }
}

/*
 * File trailer for pwchcore.c
 *
 * [EOF]
 */
